package com.example.tablas3

import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle as Bundle1


class MainActivity : AppCompatActivity(), View.OnClickListener {

    private var editText: EditText? = null
    private var button: Button? = null
    private var result: TextView? = null
    private var ans = 0

    override fun onCreate(savedInstanceState: Bundle1?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById<View>(R.id.editText) as EditText
        button = findViewById<View>(R.id.button) as Button
        result = findViewById<View>(R.id.textView) as TextView


        button!!.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.button -> {
                val buffer = StringBuffer()

                // get the input number from editText
                val fs = editText!!.text.toString()

                // convert it to integer
                val n = fs.toInt()

                // build the logic for table
                var i = 1
                while (i <= 10) {
                    ans = i * n
                    buffer.append(
                        n.toString() + " X " + i
                                + " = " + ans + "\n\n"
                    )
                    i++
                }

                // set the buffer textview
                result!!.text = buffer
            }
        }
    }
}