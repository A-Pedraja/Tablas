package com.example.tablas4

import android.os.Bundle
import android.widget.*
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.appcompat.app.AppCompatActivity
import java.util.ArrayList


class MainActivity : AppCompatActivity() {
    var textView: TextView? = null
    var listView: ListView? = null
    var seekbar: SeekBar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.textView)
        listView = findViewById(R.id.listView)
        seekbar = findViewById(R.id.seekBar)
        seekbar!!.setMax(10)
        seekbar!!.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                Toast.makeText(
                    this@MainActivity,
                    "Cargando tabla de $progress",
                    Toast.LENGTH_SHORT
                ).show()
                populate(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    fun populate(table: Int) {
        val mulTable = ArrayList<String>()
        for (i in 1..10) {
            mulTable.add(table.toString() + " X " + i + " = " + table * i)
        }
        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mulTable)
        listView!!.adapter = arrayAdapter
        textView!!.text = "Tabla de multiplicar del $table"
    }
}